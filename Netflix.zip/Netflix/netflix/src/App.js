import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import { useState, useEffect } from "react";
import NavbarComp from "./components/Navbar";
import { Routes, Route } from "react-router-dom";
import Home from "./components/Home";
import About from "./components/About";
import Cart from "./components/Cart";
import { vid } from "./utils/mocks";
import { AppContext } from "./context";
import SignIn from "./components/SignIn";
import SignUp from "./components/SignUp";

function App() {

  //api call get
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    fetch('http://localhost:8090/netflix/all')
      .then((response) => {
        if (!response.ok) {
          throw Error(response.statusText);
        }
        return response.json();
      })
      .then((data) => {
        //console.log(data);
        setData(data);
        setActualData(data);
      })
      .catch((err) => {
        console.log(err.message);
      });
  }, [])

  const [actualData, setActualData] = useState([]);
  const [data, setData] = useState([]);

  return (
    <AppContext.Provider value={{ data, setData, actualData }}>
      <NavbarComp />
      <Routes>
        <Route exact path="/" element={<Home />}></Route>
        <Route path="/about" element={<About />}></Route>
        <Route path="/cart" element={<Cart />}> </Route>
        <Route path="/signIn" element={<SignIn />}> </Route>
        <Route path="/signUp" element={<SignUp />}> </Route>
      </Routes>
    </AppContext.Provider>
  );
}

export default App;
