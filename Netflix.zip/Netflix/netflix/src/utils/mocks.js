import img1 from "../assets/msd.jpg";
import img2 from "../assets/Alchemist.jpg";
import img3 from "../assets/invisible man.jpg";
import img4 from "../assets/Ironman.jpg";
import img5 from "../assets/Batman.jpg";
import img6 from "../assets/Twilight.jpg";
import img7 from "../assets/Spiderman.jpg";
import img8 from "../assets/Titanic.jpg";
import img9 from "../assets/Founder.jpg";
import img10 from "../assets/NewMoon.jpg";
import img11 from "../assets/Ford.jpg";
import img12 from "../assets/Inception.jpg";


export const vid = [
  {
    img: img6,
    title: "Twilight ",
    des: "IMDb : 8.9",
    price: "380",
    id: 1,
    addedToCart: false,
    details : " Twilight is a 2008 American romantic fantasy film.",
  },
  {
    img: img10,
    title: "New Moon",
    des: "IMDb : 8.3",
    price: "360",
    id: 2,
    addedToCart: false,
    details : "The Twilight Saga: New Moon, commonly referred to as New Moon, is a 2009 American romantic fantasy film based on Stephenie Meyer's 2006 novel New Moon.",
  },
  
  {
    img: img3,
    title: "The Invisible man",
    des: "IMDb : 8.3",
    price: "200",
    id: 3,
    addedToCart: false,
    details : "A scientist finds a way of becoming invisible, but in doing so, he becomes murderously insane.",
  },
  {
    img: img4,
    title: "Ironman",
    des: "IMDb : 8.5",
    price: "270",
    id: 4,
    addedToCart: false,
    details : "Iron Man is a superhero appearing in American comic books published by Marvel Comics.",
  },
  {
    img: img5,
    title: "Batman",
    des: "IMDb : 9.1",
    price: "160",
    id: 5,
    addedToCart: false,
    details : "Batman is a superhero appearing in American comic books published by DC Comics.",
  },
  {
    img: img1,
    title: "Ms Dhoni",
    des: "IMDb : 8.8",
    price: "270",
    id: 6,
    addedToCart: false,
    details : "A tale about the life of Indian cricketer MS Dhoni, mapping his journey from a ticket collector to a celebrated sportsman.",
  },
  {
    img: img7,
    title: "Spiderman 3",
    des: "IMDb : 8.1",
    price: "180",
    id: 7,
    addedToCart: false,
    details : "Spider-Man 3 is a 2007 American film based on the Marvel Comics character Spider-Man.",
  },
  {
    img: img8,
    title: "Titanic",
    des: "IMDb : 8.7",
    price: "220",
    id: 8,
    addedToCart: false,
    details : "Titanic is a 1997 American epic romance and disaster film directed, written, produced by James Cameron.",
  },
  {
    img: img9,
    title: "The Founder",
    des: "IMDb : 8.2",
    price: "210",
    id: 9,
    addedToCart: false,
    details : "The Founder is a 2016 American biographical drama film directed by John Lee Hancock and written by Robert Siegel.",
  },
  {
    img: img2,
    title: "The Alchemist",
    des: "IMDb : 9.0",
    price: "150",
    id: 10,
    addedToCart: false,
    details : "The ALCHEMIST is the facinating story of a shepherd boy who dreams of travelling the world in search of Treasures.",
  },
  {
    img: img11,
    title: "Ford v Ferrari",
    des: "IMDb : 9.0",
    price: "310",
    id: 11,
    addedToCart: false,
    details : "Ford v Ferrari is a 2019 American sports drama film directed by James Mangold and written by Jez Butterworth, John-Henry Butterworth, and Jason Keller.",
  },
  {
    img: img12,
    title: "Inception",
    des: "IMDb : 9.2",
    price: "450",
    id: 12,
    addedToCart: false,
    details : "Inception is a 2010 science fiction action film written and directed by Christopher Nolan, who also produced the film with Emma Thomas, his wife.",
  },
  
];
