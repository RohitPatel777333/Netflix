import React, { useContext } from "react";
import { AppContext } from "../../context";
import "./index.css";

const Cart = () => {
  const { data, setData } = useContext(AppContext);

  const selectedItems = data.filter((val) => val.addedToCart);

  //calculation logic (totalPrice)
  const totalPrice = selectedItems.reduce((acc, val) => {
    acc += parseInt(val.price);
    return acc;
  }, 0);

  //delete button
  const removeItemFromCart = (id) => {
    const items = data.map((val) => {
      if (val.id === id) val.addedToCart = false;
      return val;
    });
    setData(items);
  };

  const emptyCart = () => {
    const items = data.map((val) => {
      val.addedToCart = false;
      return val;
    });
    setData(items);
  };

  return (
    <div>
      {selectedItems.length > 0 ? (
        <div>
          <table id="cart-table">
            <thead>
              <tr>
                <th>Sl No</th>
                <th>Id</th>
                <th>Name</th>
                <th>Price</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {selectedItems.map((val, i) => {
                return (
                  <tr key={val.id}>
                    <td> {i + 1} </td>
                    <td> {val.id} </td>
                    <td> {val.title} </td>
                    <td> ₹ {val.price} </td>
                    <td>
                      <button
                        className="btn btn-danger"
                        onClick={() => removeItemFromCart(val.id)}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          <div>
            Total Items in the cart:{" "}
            <h6 className="d-inline-block">{selectedItems.length}</h6>
          </div>
          <div>
            Total Price: <h6 className="d-inline-block">₹ {totalPrice}</h6>
          </div>
          <button className="btn btn-success" onClick={() => emptyCart()}>
            Empty Cart
          </button>
        </div>
      ) : (
        <h2 className="text-center">The cart is empty</h2>
      )}
    </div>
  );
};
export default Cart;
