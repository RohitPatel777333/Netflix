import React from "react";
import { useState, useContext } from "react";
import { AppContext } from "../../context";
import "./card.css";
import Popup from 'reactjs-popup'
import Cards from "./Cards";
import { vid } from "../../utils/mocks";

const bird1 = new Audio(
  "https://upload.wikimedia.org/wikipedia/commons/9/9b/Hydroprogne_caspia_-_Caspian_Tern_XC432679.mp3"
);

const Card = (props) => {
  const [audios, setAudios] = useState("play");
  const { data, setData } = useContext(AppContext);
  const {
    selectedCard: { img, title, des, price, id, addedToCart,viewdetails },
  } = props;
  // //api call get
  // const [posts, setPosts] = useState([]);
  // const fetchPost = () => {
  //   fetch('http://localhost:8090/netflix/all')
  //      .then((response) => {
  //         if (!response.ok) {
  //            throw Error(response.statusText);
  //         }
  //         return response.json();
  //      })
  //      .then((data) => {
  //         console.log(data);
  //         setPosts(data);
  //      })
  //      .catch((err) => {
  //         console.log(err.message);
  //      });
  //   };

  const toggle1 = () => {
    if (bird1.paused) {
      bird1.play();
      setAudios("pause");
    } else {
      bird1.pause();
      setAudios("play");
    }
  };

  const addToCart = () => {
    const items = data.map((val) => {
      if (val.id === id) val.addedToCart = true;
      return val;
    });
    setData(items);
  };

  return (
    <>
      <div className="card text-Centre">
        <div className="overflow">
        <img src={require("../../"+img)} alt="Image 1" className="card-img-top" />
          {/* <img src={img} alt="Image 1" className="card-img-top" /> */}
        </div>
        <div className="card-body text-dark"> 
          <h4 className="card-title top-right ">{title}</h4>
          <p className="card-text text-secondary text-dark ">{des}</p>
          <div className="d-flex space-around">
            <button
              className="btn btn-outline-success"
              onClick={() => toggle1()}
            >
              {audios}
            </button>
            <button
              className={`btn  ${
                addedToCart ? "btn-success" : "btn-outline-success"
              }`}
              onClick={() => addToCart()}
            >
              {addedToCart ? "Added to Cart" : "Add To Cart"}
            </button>
            <button className="btn btn-outline-success">₹ {price}</button>
          </div>
        <div>&emsp;<br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
           {/* Popup code */}
    <Popup trigger={<button className="btn btn-outline-success"> View Details</button>} 
     position=" left">
      
      <div className="card text-Centre">
        <div className="overflow">
          <img src={require("../../"+img)} alt="Image 1" className="card-img-top" />
        </div>
        <div className="card-body text-dark">
          <h4 className="card-title top-right ">{title}</h4>
          <p className="card-text text-secondary text-dark ">{des}</p>
          <p>{viewdetails}</p>
          
        </div>
      </div>   
    </Popup>
  </div>
        </div>
      </div>
    </>
  );
};

export default Card;
