import React, { Component, useContext } from "react";
import Card from "./Card";
import { AppContext } from "../../context";

const Cards = () => {
  const { data } = useContext(AppContext);
  return (
    <div className="container-fliud d-flex justify-content-center ">
      <div className=" row w-100">
        {data.map((val, i) => {
          return (
            <div className="col-md-3 disp-flex" key={i}>
              <Card
                selectedCard={val}
              />
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Cards;
