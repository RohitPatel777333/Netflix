import React, { useContext } from "react";
import Cards from "./Cards";
import Footer from "../Footer";
import { AppContext } from "../../context";

function Home(props) {
    const { setData, actualData } = useContext(AppContext);
    //search bar logic
    const handleData = (e) => {
        const value = e.target.value;
        const result = actualData.filter((val) => {
            return val.title.toLowerCase().includes(value.toLowerCase())
        });
        setData(result);
    }
    return (
        <div>
            <div className="d-flex justify-between">
                <h1>Welcome to the Netflix</h1>
                <input type="text" onChange={(e) => handleData(e)} />
            </div>
            <Cards />
            <Footer />
        </div>

    )
}

export default Home
