import { AppContext } from "../../context";
import { useContext } from "react";

const Footer = (props) => {
  const { data } = useContext(AppContext);
  return (
    <div className="footer">
      <h5> The number of contents: {data.length}</h5>
    </div>
  );
};

export default Footer;
