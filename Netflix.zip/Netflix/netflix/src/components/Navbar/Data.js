export const autoCompleteData = [
    "Ms Dhoni",
    "The Alchemist",
    "The Invisible man",
    "Ironman", 
    "Batman", 
    "Twilight",
    "Spiderman",
    "Titanic",
    "The Founder", 
    "Ford v Ferrari",
    "Inception",
    "New Moon",
  ];