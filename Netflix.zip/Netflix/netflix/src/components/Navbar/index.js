import React, { Component } from "react";
//import AutoComplete from "./Search";
import { autoCompleteData } from "./Data";
import { Navbar, Nav, Form, Container,NavDropdown } from 'react-bootstrap'
import { Link } from 'react-router-dom';
//import SearchBox from "./Search";

export default class NavbarComp extends Component {
  render() {
    return (
      <div>
        <Navbar bg="light" variant={"light"} expand="lg">
          <Container fluid>
            <Navbar.Brand >NETFLIX</Navbar.Brand>
            <Navbar.Toggle aria-controls="navbarScroll" />
            <Navbar.Collapse id="navbarScroll">
              <Nav
                className="me-auto my-2 my-lg-0"
                style={{ maxHeight: '100px' }}
                navbarScroll
              >
                <Nav.Link as={Link} to="/">Home</Nav.Link>
                <Nav.Link as={Link} to="/about">About</Nav.Link>
                <Nav.Link as={Link} to="/cart">Cart</Nav.Link>

                <NavDropdown title="Account" id="navbarScrollingDropdown">
                <NavDropdown.Item as={Link} to="/signIn">Sign In</NavDropdown.Item>
                  {/* <NavDropdown.Item href="#action4">
                    Another action
                    </NavDropdown.Item> */}
                  <NavDropdown.Divider />
                  <NavDropdown.Item as={Link} to="/signUp">Sign Up</NavDropdown.Item>
                </NavDropdown>
                    {/* <Nav.Link href="#" disabled>
                    Link
                     </Nav.Link> */}

              </Nav>
              {/* <Form className="d-flex">
                <AutoComplete data={SearchBox} />
              </Form> */}
              {/* <SearchBox 
                  placeholder={"Enter"}
                  handleChange={this.handleChange}
              /> */}
            
            </Navbar.Collapse>
          </Container>
        </Navbar>
      </div>
    )
  }
}
