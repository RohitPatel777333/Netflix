const About = () => {
    return (
        <>
        <h1> About Netflix</h1>
        <p> Netflix is a subscription-based streaming service that allows our members to watch TV shows and movies on an internet-connected device.   
                Depending on your plan, you can also download TV shows and movies to your iOS, Android, or Windows 10 device and watch without an internet connection.
            If you're already a member and would like to learn more about using Netflix, visit Getting started with Netflix.

        </p>
        <h1>Streaming service</h1>
        <p> Netflix is a streaming service that offers a wide variety of award-winning
            TV shows, movies, anime, documentaries and more – on thousands of internet-connected devices.
            You can watch as much as you want, whenever you want, without a single ad – all for one low
            monthly price.
        </p>
        <h1>TV Shows & Movies</h1>
        <p>
            Netflix content varies by region and may change over time. You can watch a variety
             of award-winning Netflix originals, TV shows, movies, documentaries, and more. 
            The more you watch, the better Netflix gets at recommending TV shows and movies.
        </p>
        <h1>Supported Devices</h1>
        <p>
            You can watch Netflix through any internet-connected device that offers the Netflix app, including smart TVs, game consoles, streaming media players, set-top boxes, smartphones, and tablets. You can also watch Netflix on your computer using an internet browser. You can review the  system requirements for web browser compatibility, and check our internet speed recommendations to achieve the best performance. 
            <br></br>
            <br></br>
            NOTE: A small percentage of devices may not be supported by all plans.
            Need help getting set up? Search our Help Center for the manufacturer of the device you're using.
            <br></br>
            <br></br>
            NOTE: The Netflix app may come pre-loaded on certain devices, or you may need to download the Netflix app onto your device. Netflix app functionality may differ between devices.
        </p>
        </>
    )
}

export default About;