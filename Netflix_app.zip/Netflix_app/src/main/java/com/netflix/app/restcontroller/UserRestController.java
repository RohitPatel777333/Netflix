package com.netflix.app.restcontroller;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.app.model.NetflixLogIn;
import com.netflix.app.model.NetflixUserDetails;
import com.netflix.app.model.Response;
import com.netflix.app.service.UserDataService;

@CrossOrigin(origins = "http://localhost:3001/")
@RestController
@RequestMapping("/userData")  //url post call
public class UserRestController {
	
	private UserDataService service;
	
	public UserRestController(UserDataService service) {
		super();
		this.service = service;
	}

	@PostMapping("/save")
	public Response saveUserDetails(@RequestBody NetflixUserDetails user  ) {
		System.out.print(user);
		return service.saveUser(user);
		
	}
	
	@PostMapping("/login")
	public Response logInDetails(@RequestBody NetflixLogIn user  ) {
		
		return service.LogIn(user);
		
		
	}
	
	@GetMapping("/all")
	public List<NetflixUserDetails> getAll(){
		return service.getAllUsers();
	}
	
	@GetMapping("/get/{email}")
	public NetflixUserDetails getByUserName(@PathVariable  String username) {
		return service.getByusername(username);
		
	}
	
	@PutMapping("/update/{email}")
	public String update(@RequestBody NetflixUserDetails user ,@PathVariable  String username ) {
		return service.UpdateUser(user, username);
		
	}
	
	@DeleteMapping("delete/{eamil}")
	public String delete(@PathVariable  String username) {
		return service.deleteUser(username);
	}
	
	
	

}
