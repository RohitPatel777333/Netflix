package com.netflix.app.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.netflix.app.model.NetflixData;
import com.netflix.app.repository.NetflixRepository;
import com.netflix.app.service.NetflixService;

@Service
public class NetflixServiceImpl implements NetflixService{

	private NetflixRepository repo;
	public NetflixServiceImpl(NetflixRepository repo) {
		super();
		this.repo = repo;
	}

	@Override
	public List<NetflixData> getAll() {
		return (List<NetflixData>)repo.findAll();
	}

	@Override
	public Optional<NetflixData> getOneBook(Integer id) {
		return repo.findById(id);
	}

	@Override
	public String saveBook(NetflixData b) {
	
		repo.save(b);
		return  "Record saved";
//		Netflixdata n 
//		if(!repo.findByemail..equals((b.getNetflixEmail()))
//		{
//			repo.save(b);
//			return b.getNetflixName() + "Record Saved";
//		}
//		else
//		{
//			System.out.println("Email Id already Exists");
//			return "Email Id already Exists";
//		}
	}

}
