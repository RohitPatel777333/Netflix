package com.netflix.app.service;

import java.util.List;
import java.util.Optional;

import com.netflix.app.model.NetflixData;




public interface NetflixService {
	
	public List<NetflixData> getAll();
	public Optional<NetflixData> getOneBook(Integer id);
	public String saveBook(NetflixData b);
	
		
	

}
