package com.netflix.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.netflix.app.model.NetflixUserDetails;

public interface UserRepository extends JpaRepository<NetflixUserDetails, Integer> {

	public NetflixUserDetails findByemail(String email);
	
	public String deleteByemail(String email);
}
