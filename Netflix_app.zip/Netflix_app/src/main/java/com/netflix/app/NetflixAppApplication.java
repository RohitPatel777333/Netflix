package com.netflix.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NetflixAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(NetflixAppApplication.class, args);
	}

}
