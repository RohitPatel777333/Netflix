package com.netflix.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.netflix.app.model.NetflixData;

public interface NetflixRepository extends JpaRepository<NetflixData, Integer> {

	
}
