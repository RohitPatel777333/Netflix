package com.netflix.app.service;

import java.util.List;

import com.netflix.app.model.NetflixLogIn;
import com.netflix.app.model.NetflixUserDetails;
import com.netflix.app.model.Response;

public interface UserDataService {
	
	
	public List<NetflixUserDetails> getAllUsers();
	
	public NetflixUserDetails getByusername(String username);
	
	public Response saveUser(NetflixUserDetails user );
	
	public String UpdateUser(NetflixUserDetails user ,String username);
	
	public String deleteUser(String username);
	
	public Response LogIn(NetflixLogIn user );
	
	
	

	
	

}
