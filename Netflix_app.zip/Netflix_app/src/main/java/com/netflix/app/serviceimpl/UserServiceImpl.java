package com.netflix.app.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.netflix.app.model.NetflixLogIn;
import com.netflix.app.model.NetflixUserDetails;
import com.netflix.app.model.Response;
import com.netflix.app.repository.UserRepository;
import com.netflix.app.service.UserDataService;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class UserServiceImpl implements UserDataService {

	private UserRepository repo;
	public UserServiceImpl(UserRepository repo) {
		super();
		this.repo = repo;
	}

	@Override
	public List<NetflixUserDetails> getAllUsers() {
		return (List<NetflixUserDetails>)repo.findAll();
	}

	@Override
	public NetflixUserDetails getByusername(String username) {
		return repo.findByemail(username);
		
	}

	@Override
	public Response saveUser(NetflixUserDetails user) {
		//user = repo.save(user);
		
		Response res = new Response();
		NetflixUserDetails us = repo.findByemail(user.getEmail());
		if(us == null) {
			user = repo.save(user);
			res.setMessage("Account successfully created");
			res.setStatus(200);
			return res;
		}
		else {
			res.setMessage("Already present");
			res.setStatus(400);
			return res;
			
		}
	
	}

	@Override
	public String UpdateUser( NetflixUserDetails user ,String username) {
		NetflixUserDetails u = repo.findByemail(username);
		u.setName(user.getName()); u.setEmail(user.getEmail());
		u.setPassword(user.getPassword());
		 repo.save(u);
		 return u.getEmail();
	}

	@Override
	public String deleteUser(String username) {
		return repo.deleteByemail(username);
	}

	@Override
	public Response LogIn(NetflixLogIn user) {
		// TODO Auto-generated method stub
		Response res = new Response();
		
		NetflixUserDetails lg = repo.findByemail(user.getEmail());
		if(lg != null) {
		if(user.getEmail().equals(lg.getEmail()) && user.getPassword().equals(lg.getPassword())) {
			
			res.setMessage("login successfull");
			res.setStatus(200);
			return res;
		}
		else {
			res.setMessage("login Failed");
			res.setStatus(400);
			return res;
			
		}}else {
			res.setMessage("no user found");
			res.setStatus(401);
			return res;
			
		}
		
//		return null;
	}

}
