package com.netflix.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BooksAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
